#########################################################################
# File Name: myshell.sh
# Author: geeker
# mail: 932834897@qq.com
# Created Time: Sun 11 Mar 2018 08:21:33 PM PDT
#########################################################################
#!/bin/bash
~/Kiloneven/Competition/sdk-gcc1/sdk-gcc/build.sh

#~/下载/sdk-gcc/bin/ecs ~/下载/初赛文档/用例示例/TrainData_2015.1.1_2015.2.19.txt  input1.txt output.txt

~/Kiloneven/Competition/sdk-gcc1/sdk-gcc/bin/ecs ~/Kiloneven/Competition/chu_sai_wen_dang/lian_xi_shu_ju/mydata2.txt input1.txt output.txt
#python pyolot.py result1.csv

#echo
#echo "the output is--->"
#echo

#cat output.txt

